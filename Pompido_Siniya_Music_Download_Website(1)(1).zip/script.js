// Add your song titles and matching MP3 filenames here.
// Put each MP3 inside the music/ folder. Example: music/my-song.mp3
const songs = [
  { title: "My First Song", description: "Pompido Siniya", file: "music/my-first-song.mp3" },
  { title: "My Second Song", description: "Pompido Siniya", file: "music/my-second-song.mp3" }
];

const songList = document.getElementById("song-list");

songs.forEach((song, index) => {
  const card = document.createElement("article");
  card.className = "song-card";
  card.innerHTML = `
    <div class="song-number">${String(index + 1).padStart(2, "0")}</div>
    <div class="song-info">
      <h3>${song.title}</h3>
      <p>${song.description}</p>
    </div>
    <div class="song-actions">
      <a class="play-btn" href="${song.file}" target="_blank" rel="noopener">▶ Play</a>
      <a class="download-btn" href="${song.file}" download>↓ Download</a>
    </div>
  `;
  songList.appendChild(card);
});

document.getElementById("year").textContent = new Date().getFullYear();
