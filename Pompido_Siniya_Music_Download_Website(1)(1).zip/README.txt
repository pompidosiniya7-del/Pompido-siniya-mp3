POMPIDO SINIYA MUSIC WEBSITE

Files:
- index.html: website page
- style.css: design
- script.js: song list
- music/: put your MP3 songs here

TO ADD YOUR MUSIC:
1. Upload your MP3 into the music folder.
2. Open script.js.
3. Replace the example title and filename with your real song name and exact MP3 filename.
4. Add another song object by copying one of the examples.

IMPORTANT:
This static GitHub Pages website can play and download music you upload to the repository.
It cannot accept permanent MP3 uploads from visitors through a website upload form.
